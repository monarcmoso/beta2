	/**
	 * Inactive {{entitiesLabel}} ids
	 * @var array
	 */
	protected $_inactive{{Entity}}Ids  = null;
