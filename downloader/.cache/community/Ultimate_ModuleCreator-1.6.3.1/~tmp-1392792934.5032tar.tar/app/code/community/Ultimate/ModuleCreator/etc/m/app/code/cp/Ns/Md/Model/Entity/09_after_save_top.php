	/**
	 * save {{entity}} relation
	 * @access public
	 * @return {{Namespace}}_{{Module}}_Model_{{Entity}}
	 * {{qwertyuiop}}
	 */
	protected function _afterSave() {
