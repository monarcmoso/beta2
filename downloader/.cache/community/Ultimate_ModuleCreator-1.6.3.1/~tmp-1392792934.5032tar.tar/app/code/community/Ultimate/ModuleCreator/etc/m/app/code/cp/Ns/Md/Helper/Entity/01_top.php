<?php 
{{License}}
/**
 * {{EntityLabel}} helper
 *
 * @category	{{Namespace}}
 * @package		{{Namespace}}_{{Module}}
 * {{qwertyuiop}}
 */
class {{Namespace}}_{{Module}}_Helper_{{Entity}} extends Mage_Core_Helper_Abstract{
