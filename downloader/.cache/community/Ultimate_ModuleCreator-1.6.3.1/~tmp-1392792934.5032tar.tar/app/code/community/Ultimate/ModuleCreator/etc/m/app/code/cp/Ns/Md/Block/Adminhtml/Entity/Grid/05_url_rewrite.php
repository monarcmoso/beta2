		$this->addColumn('url_key', array(
			'header'	=> Mage::helper('{{module}}')->__('URL key'),
			'index'		=> 'url_key',
		));
