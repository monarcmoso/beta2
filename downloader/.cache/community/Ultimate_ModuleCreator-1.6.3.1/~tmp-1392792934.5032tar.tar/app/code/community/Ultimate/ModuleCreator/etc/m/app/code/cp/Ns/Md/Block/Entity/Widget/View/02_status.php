		if (${{entity}}->getStatus()) {
