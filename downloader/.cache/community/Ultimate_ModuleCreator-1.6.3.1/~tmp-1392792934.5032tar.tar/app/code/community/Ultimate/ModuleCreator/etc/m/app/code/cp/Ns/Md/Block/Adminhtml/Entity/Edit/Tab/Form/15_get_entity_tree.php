	/**
	 * get the current {{entityLabel}}
	 * @access public
	 * @return {{Namespace}}_{{Module}}_Model_{{Entity}}
	 */
	public function get{{Entity}}(){
		return Mage::registry('{{entity}}');
	}
