		if (!$this->get{{Entity}}()->getId()) {
			$parentId = $this->getRequest()->getParam('parent');
			if (!$parentId) {
				$parentId = Mage::helper('{{module}}/{{entity}}')->getRoot{{Entity}}Id();
			}
			$fieldset->addField('path', 'hidden', array(
				'name'  => 'path',
				'value' => $parentId
			));
		} 
		else {
			$fieldset->addField('id', 'hidden', array(
				'name'  => 'id',
				'value' => $this->get{{Entity}}()->getId()
			));
			$fieldset->addField('path', 'hidden', array(
				'name'  => 'path',
				'value' => $this->get{{Entity}}()->getPath()
			));
		}
