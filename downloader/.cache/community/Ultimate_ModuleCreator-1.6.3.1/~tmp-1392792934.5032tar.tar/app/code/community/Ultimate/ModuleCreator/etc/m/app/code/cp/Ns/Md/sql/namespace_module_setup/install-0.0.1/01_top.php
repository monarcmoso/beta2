<?php 
{{License}}
/**
 * {{Module}} module install script
 *
 * @category	{{Namespace}}
 * @package		{{Namespace}}_{{Module}}
 * {{qwertyuiop}}
 */
$this->startSetup();
