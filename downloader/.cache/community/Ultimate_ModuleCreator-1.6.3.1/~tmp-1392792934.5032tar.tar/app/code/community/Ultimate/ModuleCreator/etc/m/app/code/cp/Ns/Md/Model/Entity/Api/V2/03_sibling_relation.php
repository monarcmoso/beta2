		foreach ($result->{{siblings}} as $key => $value) {
			$result->{{siblings}}[$key] = array('key' => $key, 'value' => $value);
		}
