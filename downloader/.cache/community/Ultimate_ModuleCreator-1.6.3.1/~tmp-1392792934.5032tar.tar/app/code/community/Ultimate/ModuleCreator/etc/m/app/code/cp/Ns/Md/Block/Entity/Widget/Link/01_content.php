<?php 
{{License}}
/**
 * {{EntityLabel}} link widget block
 *
 * @category	{{Namespace}}
 * @package		{{Namespace}}_{{Module}}
 * {{qwertyuiop}}
 */
class {{Namespace}}_{{Module}}_Block_{{Entity}}_Widget_Link extends {{Namespace}}_{{Module}}_Block_{{Entity}}_Widget_View{
	protected $_htmlTemplate = '{{namespace}}_{{module}}/{{entity}}/widget/link.phtml';
}