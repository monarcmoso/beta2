	const {{ENTITY}}_ROOT_ID = 1;
	/**
	 * get the root id
	 * @access public
	 * @return int
	 * {{qwertyuiop}}
	 */
	public function getRoot{{Entity}}Id(){
		return self::{{ENTITY}}_ROOT_ID;
	}
