					$breadcrumbBlock->addCrumb('{{entity}}', array(
								'label'	=> ${{entity}}->get{{EntityNameMagicCode}}(), 
								'link'	=> '',
						)
					);
				}
			}
