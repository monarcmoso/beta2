		$this->addColumn('created_at', array(
			'header'	=> Mage::helper('{{module}}')->__('Created at'),
			'index' 	=> 'created_at',
			'width' 	=> '120px',
			'type'  	=> 'datetime',
		));
