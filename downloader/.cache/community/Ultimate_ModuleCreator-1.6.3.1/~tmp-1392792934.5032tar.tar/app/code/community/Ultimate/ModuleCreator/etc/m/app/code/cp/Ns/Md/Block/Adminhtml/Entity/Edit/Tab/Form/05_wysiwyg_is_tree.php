		$fieldset->addType('editor', Mage::getConfig()->getBlockClassName('{{module}}/adminhtml_helper_wysiwyg'));
