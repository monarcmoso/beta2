<?php
{{License}}
/**
 * {{EntityLabel}} resource model
 *
 * @category	{{Namespace}}
 * @package		{{Namespace}}_{{Module}}
 * {{qwertyuiop}}
 */
class {{Namespace}}_{{Module}}_Model_Resource_{{Entity}} extends Mage_Core_Model_Resource_Db_Abstract{
