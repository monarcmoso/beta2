		$this->setDefaultFilter(array('chooser_status' => '1'));
