					$breadcrumbBlock->addCrumb('{{entities}}', array(
								'label'	=> Mage::helper('{{module}}')->__('{{EntitiesLabel}}'), 
								'link'	=> Mage::helper('{{module}}')->get{{Entities}}Url(),
						)
					);
