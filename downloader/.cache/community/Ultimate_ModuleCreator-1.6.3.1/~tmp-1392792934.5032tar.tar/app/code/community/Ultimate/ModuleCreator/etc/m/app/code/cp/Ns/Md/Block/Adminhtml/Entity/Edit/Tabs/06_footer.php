		return parent::_beforeToHtml();
	}
}