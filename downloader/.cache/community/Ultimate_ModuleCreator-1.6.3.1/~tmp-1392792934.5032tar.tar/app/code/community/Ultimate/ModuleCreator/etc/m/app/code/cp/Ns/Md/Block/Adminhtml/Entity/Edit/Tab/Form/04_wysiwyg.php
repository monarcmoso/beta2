		$wysiwygConfig = Mage::getSingleton('cms/wysiwyg_config')->getConfig();
