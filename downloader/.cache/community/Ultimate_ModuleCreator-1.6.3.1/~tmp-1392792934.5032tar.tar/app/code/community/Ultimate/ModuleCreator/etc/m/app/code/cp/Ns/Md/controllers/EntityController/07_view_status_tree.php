		elseif (!${{entity}}->getStatusPath()){
			$this->_forward('no-route');
		}
