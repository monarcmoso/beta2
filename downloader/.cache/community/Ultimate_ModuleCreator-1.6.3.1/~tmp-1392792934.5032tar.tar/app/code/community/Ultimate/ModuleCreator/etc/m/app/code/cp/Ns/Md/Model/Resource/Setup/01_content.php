<?php 
{{License}}
/**
 * {{Module}} setup
 *
 * @category	{{Namespace}}
 * @package		{{Namespace}}_{{Module}}
 * {{qwertyuiop}}
 */
class {{Namespace}}_{{Module}}_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup{
	
}