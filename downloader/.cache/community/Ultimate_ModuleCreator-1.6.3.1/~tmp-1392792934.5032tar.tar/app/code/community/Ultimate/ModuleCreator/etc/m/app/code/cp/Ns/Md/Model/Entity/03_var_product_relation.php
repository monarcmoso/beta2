	protected $_productInstance = null;
