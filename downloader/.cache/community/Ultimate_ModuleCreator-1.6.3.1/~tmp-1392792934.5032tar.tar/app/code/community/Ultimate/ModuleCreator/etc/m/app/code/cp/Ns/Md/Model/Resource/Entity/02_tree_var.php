	/**
	 * {{EntityLabel}} tree object
	 * @var Varien_Data_Tree_Db
	 */
	protected $_tree;
