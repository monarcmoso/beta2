		$this->getProductInstance()->save{{Entity}}Relation($this);
