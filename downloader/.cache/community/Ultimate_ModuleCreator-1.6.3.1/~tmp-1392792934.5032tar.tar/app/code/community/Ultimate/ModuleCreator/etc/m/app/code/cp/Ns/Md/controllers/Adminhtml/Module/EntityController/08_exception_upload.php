				if (isset($data['{{attributeCode}}']['value'])){
					$data['{{attributeCode}}'] = $data['{{attributeCode}}']['value'];
				}
