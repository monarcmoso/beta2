	/**
	 * get the url to the {{entitiesLabel}} list page
	 * @access public
	 * @return string
	 * {{qwertyuiop}}
	 */
	public function get{{Entities}}Url(){
		return Mage::getUrl('{{module}}/{{entity}}/index');
	}
