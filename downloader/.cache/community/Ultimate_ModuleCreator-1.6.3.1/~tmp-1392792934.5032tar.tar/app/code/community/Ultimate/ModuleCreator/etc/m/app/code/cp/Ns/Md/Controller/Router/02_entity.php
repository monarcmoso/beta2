		$check['{{entity}}'] = new Varien_Object(array(
			'model' =>'{{module}}/{{entity}}',
			'controller' => '{{entity}}',
			'action' => 'view',
			'param'	=> 'id',
		));
