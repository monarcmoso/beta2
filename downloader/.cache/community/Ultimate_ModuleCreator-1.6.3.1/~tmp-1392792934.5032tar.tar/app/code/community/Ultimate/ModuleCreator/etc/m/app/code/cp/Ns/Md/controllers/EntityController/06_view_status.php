		elseif (!${{entity}}->getStatus()){
			$this->_forward('no-route');
		}
