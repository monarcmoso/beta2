<?php
{{License}}
/**
 * Product helper
 *
 * @category	{{Namespace}}
 * @package		{{Namespace}}_{{Module}}
 * {{qwertyuiop}}
 */
class {{Namespace}}_{{Module}}_Helper_Product extends {{Namespace}}_{{Module}}_Helper_Data{
