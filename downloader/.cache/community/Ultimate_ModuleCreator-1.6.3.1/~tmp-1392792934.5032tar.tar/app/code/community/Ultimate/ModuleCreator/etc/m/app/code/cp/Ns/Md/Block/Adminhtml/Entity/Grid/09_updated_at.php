		$this->addColumn('updated_at', array(
			'header'	=> Mage::helper('{{module}}')->__('Updated at'),
			'index' 	=> 'updated_at',
			'width' 	=> '120px',
			'type'  	=> 'datetime',
		));
