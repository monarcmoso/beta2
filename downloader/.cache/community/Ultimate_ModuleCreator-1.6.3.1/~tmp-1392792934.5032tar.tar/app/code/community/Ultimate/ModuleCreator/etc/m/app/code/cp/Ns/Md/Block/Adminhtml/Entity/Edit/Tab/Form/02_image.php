		$fieldset->addType('image', Mage::getConfig()->getBlockClassName('{{module}}/adminhtml_{{entity}}_helper_image'));
