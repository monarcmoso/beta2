				$this->setCurrent{{Entity}}(${{entity}});
				$this->setTemplate($this->_htmlTemplate);
