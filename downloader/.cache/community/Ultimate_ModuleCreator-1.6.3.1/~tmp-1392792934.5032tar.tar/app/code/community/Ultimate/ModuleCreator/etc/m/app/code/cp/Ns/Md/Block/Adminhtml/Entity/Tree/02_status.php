		if ($node->getStatus()){
			$item['cls'] .= ' active-category';
		}
		else{
			$item['cls'] .= ' no-active-category';
		}
