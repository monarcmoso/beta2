<?php 
{{License}}
/**
 * {{EntityLabel}} front contrller
 *
 * @category	{{Namespace}}
 * @package		{{Namespace}}_{{Module}}
 * {{qwertyuiop}}
 */
class {{Namespace}}_{{Module}}_{{Entity}}Controller extends Mage_Core_Controller_Front_Action{
