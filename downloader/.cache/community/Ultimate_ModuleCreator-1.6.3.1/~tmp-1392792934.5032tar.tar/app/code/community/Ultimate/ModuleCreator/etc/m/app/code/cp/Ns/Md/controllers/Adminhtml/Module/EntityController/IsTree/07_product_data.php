				$products = $this->getRequest()->getPost('{{entity}}_products', -1);
				if ($products != -1) {
					$productData = array();
					parse_str($products, $productData);
					$products = array();
					foreach ($productData as $id=>$position){
						$products[$id]['position'] = $position;
					}
					${{entity}}->setProductsData($productData);
				}

