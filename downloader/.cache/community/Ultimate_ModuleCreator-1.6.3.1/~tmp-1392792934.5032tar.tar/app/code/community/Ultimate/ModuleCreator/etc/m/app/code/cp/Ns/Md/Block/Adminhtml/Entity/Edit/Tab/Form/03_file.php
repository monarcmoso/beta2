		$fieldset->addType('file', Mage::getConfig()->getBlockClassName('{{module}}/adminhtml_{{entity}}_helper_file'));
