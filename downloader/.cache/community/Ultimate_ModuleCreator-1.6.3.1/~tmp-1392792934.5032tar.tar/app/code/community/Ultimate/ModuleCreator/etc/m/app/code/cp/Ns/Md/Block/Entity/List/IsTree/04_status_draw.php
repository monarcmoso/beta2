		if (!${{entity}}->getStatus()){
			return '';
		}
