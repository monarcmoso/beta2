		$children = ${{entity}}->getChildren{{Entities}}();
