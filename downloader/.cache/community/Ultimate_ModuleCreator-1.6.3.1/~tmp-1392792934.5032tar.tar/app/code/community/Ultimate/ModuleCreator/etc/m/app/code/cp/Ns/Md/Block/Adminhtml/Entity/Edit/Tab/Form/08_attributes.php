{{attributePreElementText}}
		$fieldset->addField('{{attributeCode}}', '{{attributeFormType}}', array(
			'label' => Mage::helper('{{module}}')->__('{{attributeLabel}}'),
			'name'  => '{{attributeCode}}',
{{attributeFormOptions}}		));
