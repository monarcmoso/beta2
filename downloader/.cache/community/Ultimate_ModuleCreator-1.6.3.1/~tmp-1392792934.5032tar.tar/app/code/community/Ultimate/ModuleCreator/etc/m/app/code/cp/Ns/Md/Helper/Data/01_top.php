<?php 
{{License}}
/**
 * {{Module}} default helper
 *
 * @category	{{Namespace}}
 * @package		{{Namespace}}_{{Module}}
 * {{qwertyuiop}}
 */
class {{Namespace}}_{{Module}}_Helper_Data extends Mage_Core_Helper_Abstract{
