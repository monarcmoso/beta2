		$this->addExportType('*/*/exportCsv', Mage::helper('{{module}}')->__('CSV'));
		$this->addExportType('*/*/exportExcel', Mage::helper('{{module}}')->__('Excel'));
		$this->addExportType('*/*/exportXml', Mage::helper('{{module}}')->__('XML'));
